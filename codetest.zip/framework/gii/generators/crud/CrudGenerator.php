<?php

class CrudGenerator extends CCodeGenerator
{
	public $codeModel='gii.generators.crud.CrudCode';
}